# Burnout: Breaking the Cycle

A student-created site about recognizing and recovering from burnout.

## How to Publish on GitHub Pages
1. Go to https://github.com/new and create a repo called `burnout-website`.
2. Upload the contents of this folder (index.html and style.css).
3. In the repo settings, enable GitHub Pages under "Pages" → Source → main branch → Save.
4. Visit your live site at: https://<your-username>.github.io/burnout-website/
